package ma.formations.jpa.service;

public class arb {
}
