package ma.formations.jpa.presentation;

public class arb2 {
}
